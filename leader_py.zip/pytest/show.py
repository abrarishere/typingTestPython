# show.py

import sys
import time


def display_progress(username, passage):
    print("\nGet ready for the typing test...\n")
    time.sleep(2)
    print("Begin typing when ready.\n")

    passage_words = passage.split()
    num_words = len(passage_words)
    start_time = time.time()
    correct_words = 0
    correct_characters = 0
    total_characters = 0

    for i, word in enumerate(passage_words):
        sys.stdout.write(f"\rProgress: {i}/{num_words} words | WPM: {calculate_wpm(start_time, correct_characters, total_characters):.2f} | Accuracy: {calculate_accuracy(correct_words, i):.2f}%")
        sys.stdout.flush()

        typed_word = input(f"\nType the word '{word}': ")
        total_characters += len(word)

        if typed_word == word:
            correct_words += 1
            correct_characters += len(word)
        else:
            print("Incorrect. Try again.")

    wpm = calculate_wpm(start_time, correct_characters, total_characters)
    accuracy = calculate_accuracy(correct_words, num_words)
    print("\nTyping test completed!")
    print(f"Words per minute (WPM): {wpm:.2f}")
    print(f"Accuracy: {accuracy:.2f}%")

    return wpm, accuracy

def calculate_wpm(start_time, correct_characters, total_characters):
    minutes_elapsed = (time.time() - start_time) / 60
    if minutes_elapsed == 0:
        return 0
    else:
        return (correct_characters / 5) / minutes_elapsed

def calculate_accuracy(correct_words, total_words):
    if total_words == 0:
        return 0
    else:
        return (correct_words / total_words) * 100

