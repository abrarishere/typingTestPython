# intro.py

def display_intro():
    print("Welcome to the World's Most Prestigious Typing Competition!")
    print("Are you ready to showcase your typing skills against the best?\n")
    print("Instructions:")
    print("- You will be presented with a random passage to type.")
    print("- Type each word accurately and quickly to maximize your score.")
    print("- Your typing speed and accuracy will be evaluated at the end.\n")

