# main.py

import intro
import leaderboard
import results
import setup
import show


def main():
    intro.display_intro()
    username = input("Enter your username: ")
    choice = input("\nWould you like to view the leaderboard? (yes/no): ").lower()
    if choice == "yes":
        leaderboard.display_leaderboard()
    words = setup.load_words("words.txt")
    difficulty = setup.select_difficulty()
    passage = setup.select_passage(words, difficulty)
    wpm, accuracy = show.display_progress(username, passage)
    results.display_results(wpm, accuracy)
    leaderboard.update_leaderboard(username, wpm, accuracy)
    leaderboard.display_leaderboard()

if __name__ == "__main__":
    main()

